import { Container, Row, Col, Image } from "react-bootstrap"
 
function ServiceSection(){
    return(
        <Container className="my-5">
            <Row>
                <Col md={4} className='mb-3 text-center py-3'>
                <Image src="/images/beig.jpg" alt="service 1" fluid/>
                <h3>Service 1</h3>
                <p>Description of service 1</p>
                </Col>
                 <Col md={4} className='mb-3 text-center py-3'>
                <Image src="/images/beig.jpg" alt="service 1" fluid/>
                <h3>Service 2</h3>
                <p>Description of service 2</p>
                </Col>
                 <Col md={4} className='mb-3 text-center py-3'>
                <Image src="/images/beig.jpg" alt="service 1" fluid/>
                <h3>Service 3</h3>
                <p>Description of service 3</p>
                </Col>
            </Row>
        </Container>
    )
}
 
export default ServiceSection;