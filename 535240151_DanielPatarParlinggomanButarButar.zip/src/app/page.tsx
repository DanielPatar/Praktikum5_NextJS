"use client";
import React from "react";
import Hero from "../../components/herosection";
import { Container } from "react-bootstrap";
import { Row } from "react-bootstrap";
import { Col } from "react-bootstrap";
import { Button } from "react-bootstrap";
import { Image } from "react-bootstrap";
 
export default function Home() {
  return (
<div>
<Hero />
<Container className="my-5">
<Row className="my-4">
<Col md={6} className="align-self-center mb-3">
<h2>About Us</h2>
<h6>What We Do?</h6>
<p>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Animi
              necessitatibus aspernatur ea iusto eius deleniti nesciunt ullam
              blanditiis excepturi quas.
</p>
<Button variant="info">Learn More</Button>
</Col>
<Col md={6}>
<p>
<Image src="/images/Banner1.png" alt="About us" fluid />
</p>
</Col>
</Row>
</Container>
</div>
  );
};